# Resume Critiq — Job Description vs Resume Analyzer

A full-stack Next.js app that:
- Scrapes a job posting URL for the description
- Accepts a resume (PDF) or resume URL
- Uses OpenAI GPT‑5 (configurable) to critique strengths, gaps, keywords, and buzzwords
- Calculates a coverage score and gives actionable edits

## Quick Start

### 1) Prereqs
- Node.js 20+ and npm
- An OpenAI API key from https://platform.openai.com/

### 2) Setup
```bash
cp .env.example .env.local
# edit .env.local and set OPENAI_API_KEY, optionally OPENAI_MODEL
npm install
npm run dev
```
Open http://localhost:3000

### 3) Usage
- Paste a job posting URL
- Upload a PDF resume **or** paste a resume URL
- Click **Analyze**

### Notes / Gotchas
- Respect websites' Terms of Service. This app fetches the URL you provide and heuristically extracts the main text for analysis.
- Some job boards block scraping. If extraction looks sparse, paste the JD text into a simple pastebin or company career page link and try again.
- PDF parsing uses `pdf-parse`. Complex PDFs may occasionally extract with odd spacing—still fine for analysis.
- The OpenAI model is configurable via `OPENAI_MODEL`. Defaults to `gpt-5-mini` for cost/latency. Use `gpt-5` for maximum quality.

### Deploy
- Local is easiest. If you deploy (e.g., Vercel), add the same env vars in the hosting provider.
- This repo is a standard Next.js app; `npm run build && npm start` works on most Node hosts.

## Tech
- Next.js App Router (API routes in `/app/api`)
- Tailwind CSS
- `cheerio` + `html-to-text` for extraction
- `pdf-parse` for PDFs
- OpenAI Responses API with Structured Outputs (strict JSON schema)
