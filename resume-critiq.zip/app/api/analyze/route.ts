import { NextRequest, NextResponse } from "next/server";
export const runtime = "nodejs";

import OpenAI from "openai";
import pdfParse from "pdf-parse";
import { fetchAndExtract } from "@/lib/extract";
import { topKeywords, coverage, overusedBuzzwords } from "@/lib/keywords";

const MAX_CHARS = 16000;

function clip(s: string) {
  if (!s) return s;
  return s.length > MAX_CHARS ? s.slice(0, MAX_CHARS) : s;
}

async function extractResumeFromUrl(resumeUrl: string): Promise<string> {
  const res = await fetch(resumeUrl, { headers: { "user-agent": "Mozilla/5.0" } });
  if (!res.ok) throw new Error(`Failed to fetch resume URL (${res.status})`);
  const ct = res.headers.get("content-type") || "";
  if (ct.includes("pdf")) {
    const buf = Buffer.from(await res.arrayBuffer());
    const data = await pdfParse(buf);
    return data.text;
  } else if (ct.includes("html") || ct.includes("text")) {
    const html = await res.text();
    const { htmlToText } = await import("html-to-text");
    return htmlToText(html, { wordwrap: 120 });
  } else {
    throw new Error(`Unsupported resume content-type: ${ct}`);
  }
}

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();
    const jobUrl = String(form.get("jobUrl") || "");
    const resumeUrl = String(form.get("resumeUrl") || "");
    const file = form.get("resumeFile") as unknown as File | null;

    if (!jobUrl) {
      return new NextResponse("jobUrl is required", { status: 400 });
    }

    const [jobText, resumeTextRaw] = await Promise.all([
      fetchAndExtract(jobUrl),
      (async () => {
        if (resumeUrl) return await extractResumeFromUrl(resumeUrl);
        if (file && typeof file.arrayBuffer === "function") {
          const arrayBuffer = await file.arrayBuffer();
          const buf = Buffer.from(arrayBuffer);
          const data = await pdfParse(buf);
          return data.text;
        }
        throw new Error("Provide a resume URL or upload a PDF file.");
      })()
    ]);

    const resumeText = resumeTextRaw.trim();
    const jobTextClipped = clip(jobText);
    const resumeTextClipped = clip(resumeText);

    // Basic heuristic keywords
    const jdKeywords = topKeywords(jobTextClipped, 40);
    const cov = coverage(jdKeywords, resumeTextClipped);
    const buzz = overusedBuzzwords(resumeTextClipped);

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const model = process.env.OPENAI_MODEL || "gpt-5-mini";

    const schema = {
      name: "ResumeCritique",
      schema: {
        type: "object",
        additionalProperties: false,
        properties: {
          score: { type: "integer", minimum: 0, maximum: 100 },
          summary: { type: "string" },
          strengths: { type: "array", items: { type: "string" } },
          improvements: { type: "array", items: { type: "string" } },
          missingKeywords: { type: "array", items: { type: "string" } },
          matchedKeywords: { type: "array", items: { type: "string" } },
          buzzwordOveruse: { type: "array", items: { type: "string" } },
          atsChecks: {
            type: "object",
            additionalProperties: false,
            properties: {
              fileFormat: { type: "string" },
              contactInfoPresent: { type: "boolean" },
              linksOk: { type: "boolean" },
              length: { type: "string" },
              education: { type: "boolean" },
              workExperience: { type: "boolean" }
            },
            required: ["fileFormat","contactInfoPresent","linksOk","length","education","workExperience"]
          },
          tailoredBullets: { type: "array", items: { type: "string" } }
        },
        required: ["score","summary","strengths","improvements","missingKeywords","matchedKeywords","buzzwordOveruse","atsChecks","tailoredBullets"]
      },
      strict: true
    } as const;

    const prompt = [
      {
        role: "system",
        content: [
          { type: "text", text: "You are an expert resume reviewer and recruiter. Evaluate the resume against the job description. Prefer concrete, measurable, resume-ready suggestions over generic advice. Return strictly the JSON schema provided by the tool." }
        ]
      },
      {
        role: "user",
        content: [
          { type: "text", text: `JOB DESCRIPTION (truncated ${jobTextClipped.length} chars):\n\n${jobTextClipped}` },
          { type: "text", text: `RESUME (truncated ${resumeTextClipped.length} chars):\n\n${resumeTextClipped}` },
          { type: "text", text: `SEED KEYWORDS FROM JD: ${jdKeywords.join(", ")}` },
          { type: "text", text: `HEURISTIC COVERAGE (matched ${cov.matched.length}, missing ${cov.missing.length})` },
          { type: "text", text: `BUZZWORDS IN RESUME: ${buzz.join(", ") || "none"}` },
          { type: "text", text: "Score from 0-100 balancing keyword coverage (40%), seniority fit (20%), quantifiable impact (20%), and clarity/ATS friendliness (20%). Provide tailored bullets that mirror the JD language." }
        ]
      }
    ] as any;

    const resp = await client.responses.create({
      model,
      input: prompt,
      response_format: { type: "json_schema", json_schema: schema }
    });

    const outputText: string | undefined = (resp as any).output_text;
    let parsed: any = null;
    if (outputText) {
      try {
        parsed = JSON.parse(outputText);
      } catch (e) {
        // Fallback: minimal object
        parsed = {
          score: Math.round((cov.matched.length / Math.max(1, jdKeywords.length)) * 100),
          summary: "Model parsing failed; fallback summary based on heuristic coverage.",
          strengths: cov.matched.slice(0,10),
          improvements: cov.missing.slice(0,10).map(k => `Add or evidence: ${k}`),
          missingKeywords: cov.missing,
          matchedKeywords: cov.matched,
          buzzwordOveruse: buzz,
          atsChecks: { fileFormat: "PDF", contactInfoPresent: false, linksOk: true, length: "n/a", education: true, workExperience: true },
          tailoredBullets: []
        };
      }
    } else {
      // Defensive fallback
      parsed = {
        score: Math.round((cov.matched.length / Math.max(1, jdKeywords.length)) * 100),
        summary: "Model returned an unexpected format; showing heuristic results.",
        strengths: cov.matched.slice(0,10),
        improvements: cov.missing.slice(0,10).map(k => `Add or evidence: ${k}`),
        missingKeywords: cov.missing,
        matchedKeywords: cov.matched,
        buzzwordOveruse: buzz,
        atsChecks: { fileFormat: "PDF", contactInfoPresent: false, linksOk: true, length: "n/a", education: true, workExperience: true },
        tailoredBullets: []
      };
    }

    if (process.env.DEBUG === "true") {
      console.log("JD keywords:", jdKeywords);
      console.log("Coverage:", cov);
    }

    return NextResponse.json({
      analysis: parsed,
      previews: {
        jobText: jobTextClipped.slice(0, 4000),
        resumeText: resumeTextClipped.slice(0, 4000)
      }
    });
  } catch (e: any) {
    const message = e?.message || "Internal error";
    if (process.env.DEBUG === "true") console.error(e);
    return new NextResponse(message, { status: 500 });
  }
}
