"use client";
import React, { useState } from "react";

type Analysis = {
  score: number;
  summary: string;
  strengths: string[];
  improvements: string[];
  missingKeywords: string[];
  matchedKeywords: string[];
  buzzwordOveruse: string[];
  atsChecks: {
    fileFormat: string;
    contactInfoPresent: boolean;
    linksOk: boolean;
    length: string;
    education: boolean;
    workExperience: boolean;
  };
  tailoredBullets: string[];
};

export default function Home() {
  const [jobUrl, setJobUrl] = useState("");
  const [resumeUrl, setResumeUrl] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Analysis | null>(null);
  const [jdPreview, setJdPreview] = useState<string>("");
  const [resumePreview, setResumePreview] = useState<string>("");

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setResult(null);
    setJdPreview("");
    setResumePreview("");
    setLoading(true);
    try {
      const form = new FormData();
      form.append("jobUrl", jobUrl);
      form.append("resumeUrl", resumeUrl);
      if (file) form.append("resumeFile", file);
      const res = await fetch("/api/analyze", {
        method: "POST",
        body: form,
      });
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg || "Request failed");
      }
      const data = await res.json();
      setResult(data.analysis);
      setJdPreview(data.previews?.jobText || "");
      setResumePreview(data.previews?.resumeText || "");
    } catch (err: any) {
      setError(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="container py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Resume Critiq</h1>
        <p className="text-gray-600 mt-1">Paste a job link + drop your PDF resume or resume URL. Get an ATS-style critique with a score.</p>
      </div>

      <form onSubmit={onSubmit} className="card p-5 space-y-4">
        <div>
          <label className="label">Job posting URL</label>
          <input className="input mt-1" type="url" required placeholder="https://careers.company.com/jobs/12345" value={jobUrl} onChange={(e)=>setJobUrl(e.target.value)} />
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="label">Resume URL (optional)</label>
            <input className="input mt-1" type="url" placeholder="https://your-portfolio.site/resume" value={resumeUrl} onChange={(e)=>setResumeUrl(e.target.value)} />
          </div>
          <div>
            <label className="label">Or upload PDF resume</label>
            <input className="input mt-1" type="file" accept="application/pdf" onChange={(e)=>setFile(e.target.files?.[0] || null)} />
          </div>
        </div>
        <button className="btn" disabled={loading}>{loading ? "Analyzing..." : "Analyze"}</button>
        {error && <p className="text-red-600">{error}</p>}
      </form>

      {result && (
        <div className="mt-8 grid gap-6">
          <div className="card p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Overall Score</h2>
              <span className="text-2xl font-bold">{result.score}/100</span>
            </div>
            <div className="progress mt-3"><div style={{ width: `${result.score}%` }} /></div>
            <p className="mt-3 text-gray-700">{result.summary}</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="card p-5">
              <h3 className="text-lg font-semibold">Strengths</h3>
              <ul className="list-disc pl-6 mt-2">{result.strengths.map((s,i)=>(<li key={i}>{s}</li>))}</ul>
            </div>
            <div className="card p-5">
              <h3 className="text-lg font-semibold">Improvements</h3>
              <ul className="list-disc pl-6 mt-2">{result.improvements.map((s,i)=>(<li key={i}>{s}</li>))}</ul>
            </div>
          </div>

          <div className="card p-5">
            <h3 className="text-lg font-semibold">Keywords</h3>
            <div className="mt-2">
              <h4 className="font-medium">Matched</h4>
              <div className="mt-1">{result.matchedKeywords.map((k,i)=>(<span key={i} className="badge border-green-300 text-green-700">{k}</span>))}</div>
            </div>
            <div className="mt-3">
              <h4 className="font-medium">Missing</h4>
              <div className="mt-1">{result.missingKeywords.map((k,i)=>(<span key={i} className="badge border-red-300 text-red-700">{k}</span>))}</div>
            </div>
            {result.buzzwordOveruse.length>0 && (
              <div className="mt-3">
                <h4 className="font-medium">Buzzword Overuse</h4>
                <div className="mt-1">{result.buzzwordOveruse.map((k,i)=>(<span key={i} className="badge border-amber-300 text-amber-700">{k}</span>))}</div>
              </div>
            )}
          </div>

          <div className="card p-5">
            <h3 className="text-lg font-semibold">ATS Checks</h3>
            <ul className="list-disc pl-6 mt-2 text-gray-800">
              <li>Format: <b>{result.atsChecks.fileFormat}</b></li>
              <li>Contact info present: <b>{result.atsChecks.contactInfoPresent ? "Yes" : "No"}</b></li>
              <li>Links OK: <b>{result.atsChecks.linksOk ? "Yes" : "Potential issues"}</b></li>
              <li>Length: <b>{result.atsChecks.length}</b></li>
              <li>Education section: <b>{result.atsChecks.education ? "Present" : "Missing"}</b></li>
              <li>Work experience section: <b>{result.atsChecks.workExperience ? "Present" : "Missing"}</b></li>
            </ul>
          </div>

          {result.tailoredBullets.length>0 && (
            <div className="card p-5">
              <h3 className="text-lg font-semibold">Tailored Bullet Suggestions</h3>
              <ul className="list-disc pl-6 mt-2">{result.tailoredBullets.map((s,i)=>(<li key={i}>{s}</li>))}</ul>
            </div>
          )}

          <div className="grid md:grid-cols-2 gap-6">
            <div className="card p-5">
              <h3 className="text-lg font-semibold">Job Description (extracted)</h3>
              <pre className="whitespace-pre-wrap text-sm mt-2 max-h-72 overflow-auto">{jdPreview}</pre>
            </div>
            <div className="card p-5">
              <h3 className="text-lg font-semibold">Resume (extracted)</h3>
              <pre className="whitespace-pre-wrap text-sm mt-2 max-h-72 overflow-auto">{resumePreview}</pre>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
